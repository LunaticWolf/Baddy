function validation()
{
var pincode =document.userForm.customer_pinCode.value;
var numbers = /^[0-9]+$/;
var email = document.userForm.email_address.value;
var con=document.userForm.contact_number.value;
var name=document.userForm.customer_name.value;
var letters = /^[A-Za-z]+$/;
var Email = /^([a-z A-Z 0-9 _\.\-])+\@(([a-z A-Z 0-9\-])+\.)+([a-z A-z 0-9]{3,3})+$/;
var add1=document.userForm.customerAddressOne.value;
var flag=0;

if(pincode.match(numbers)){
	
}
else{
	alert('pincode should be a 6-digit Number');
	flag++;
}
if(pincode.length==6){}
else{
	alert('pincode should be a 6-digit Number');
	
}
if(email.match(Email)){
	
}
else {
	alert('Enter valid email');
	flag++;
}

 if (name==null || name=="")
{
alert("Please enter your name");
      flag++;
  }
 if(name.match(letters))
{

}
else
{
alert('Username must have alphabet characters only');
flag++;
}
if((con.match(numbers)))
{

}
else{
alert('Enter valid contact number');
flag++;}

if(con.length==0)
{
alert('Field cannot be empty');
}

if(add1.length==0)
{
alert('Address field cannot be empty');
return false;
}


if(con.length!=10)
{
alert('Contact Number should be a 10 digit number');
return false;
}

if(flag)
{
alert('Please Enter the Right Details for login');

return false;
}
else return true;
}
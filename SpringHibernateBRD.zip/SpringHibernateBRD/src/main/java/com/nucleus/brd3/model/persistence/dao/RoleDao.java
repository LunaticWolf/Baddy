package com.nucleus.brd3.model.persistence.dao;

import java.util.List;

import com.nucleus.brd3.model.persistence.entity.User;

public interface RoleDao {

	public void saveRecord(User user);
	public List<User> viewUserName(); 
	public String encodePwd(String pwd);
}

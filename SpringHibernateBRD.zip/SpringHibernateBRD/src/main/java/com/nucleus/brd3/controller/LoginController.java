package com.nucleus.brd3.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;




@Controller
public class LoginController 
{
	final static Logger LOGGER=Logger.getLogger(LoginController.class);
	
	private static String targetUrl=null;
	
	@RequestMapping("/accdenied")
	public String requestHandler1()
	{
		/*return "checker";*/
		targetUrl="checker";
		return targetUrl;
		
	}
	
	
	@RequestMapping("/login")
	public String requestHandler2()
	{
		/*return "login";*/
		targetUrl="login";
		return targetUrl;
		
	}
	
	
	@RequestMapping("/loginfailure")
	public ModelAndView requestHandler3()
	{
		return new ModelAndView("login" , "error" , "Wrong credentials");
	}
	
	@RequestMapping("/defaultpage")
	public String requestHandler3(Authentication authentication,HttpServletRequest request)
	{
		Authentication auth=SecurityContextHolder.getContext().getAuthentication();
		String role=auth.getAuthorities().toString(); 	
		/*String targetUrl=null;*/
		if(request.isUserInRole("ROLE_USER"))
		{
			targetUrl="redirect:/index";
		}
		else if(request.isUserInRole("ROLE_ADMIN"))
		{
			targetUrl="redirect:/checker";
		}
		else
			targetUrl="redirect:/";
		
		return targetUrl;
	}
	

}

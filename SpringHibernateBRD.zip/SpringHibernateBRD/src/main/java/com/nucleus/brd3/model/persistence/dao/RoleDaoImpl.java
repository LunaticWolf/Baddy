package com.nucleus.brd3.model.persistence.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.brd3.model.persistence.entity.User;

@Repository
public class RoleDaoImpl implements RoleDao
{
	@Autowired
	SessionFactory sessionFactory;
	
	
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;
	
	
	

	
	 
	public void saveRecord(User user) {
		
		
		user.setEnabled(1);
		String enocodedpassword=encodePwd(user.getPassword());
		user.setPassword(enocodedpassword);
		
		sessionFactory.getCurrentSession().saveOrUpdate(user);	
	}

	 
	public List<User> viewUserName() 
	{
		List<User> userName=new ArrayList<User>();
		Query query=sessionFactory.getCurrentSession().createQuery("from User");
		userName=query.list();
		return userName;
	}
	
	public String encodePwd(String pwd) 
	{
		return bCryptPasswordEncoder.encode(pwd);
		
	}


}
